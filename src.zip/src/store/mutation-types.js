/*
包含n个mutation名称常量的模块
 */
export const RECEIVE_ADDRESS = 'receive_address'
export const RECEIVE_CATEGORYS = 'receive_categorys'
export const RECEIVE_SHOPS = 'receive_shops'
export const RECEIVE_USER = 'receive_user'
